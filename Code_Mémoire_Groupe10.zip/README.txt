Informations générales:

Ce site web a été développé en html/css/php/js dans le cadre d'un TER de l'UE HLIN405 de l'Université de Montpellier.

Utilisation:

Lancer la page Index.html, s'inscrire, se connecter.
Vous pouvez ensuite suivre les options qui sont apparues sur les onglets du site afin de créer un tournoi puis des équipes et de générer des matchs.
Une fois les matchs générés, rentrez les scores de chaque match.
Enfin, allez dans l'onglet "Liste des tournois" afin d'afficher l'arbre en cliquant sur la ligne correspondant à votre tournoi.

Conseils:

Afin de faire un test rapide, vous pouvez utiliser le tournoi qui est généré dans le fichier db_tournoi.
Il manque volontairement un capitaine dans l'équipe Sevilla afin de montrer qu'un tournoi ne se génère pas si toutes les équipes n'ont pas un capitaine.
Une erreur apparaitra, il vous suffira alors de désigner un capitaine pour l'équipe en question.
De même, si vous essayez d'ajouter une équipe à un tournoi qui a déjà atteint son nombre d'équipes maximum, vous obtiendrez un message d'erreur.